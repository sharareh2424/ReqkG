# Dataset documentation

## 1. Fault-Prone SRS

- **Configured source:** Kaggle dataset `corpus4panwo/fault-prone-srs-dataset`.
- **File expected by loader:** `dataset.csv`.
- **Format:** CSV.
- **Role:** requirement ambiguity detection and classification.
- **Acquisition:** KaggleHub client, with a public Kaggle download endpoint as fallback.
- **Runtime metadata:** the notebook records the detected encoding, acquisition route, row/column counts, local path, and SHA-256 hash in its dataset manifest.

## 2. ORCHID

- **Configured source:** Hugging Face dataset repository `SII-YDD/Orchid`.
- **File:** `Orchid-HEval/data.jsonl`.
- **Format:** JSON Lines (one JSON object per line).
- **Role:** requirement clarification/repair evaluation and reference-based diagnostics.
- **Revision:** configured as `main`; this is a moving reference. For a frozen replication, record the exact resolved commit/revision from the run and update the configuration only after verifying it.

## 3. QuRE

- **Configured source:** Zenodo record `16049822`; fallback record `15656472`.
- **File:** `QuRE.csv`.
- **Format:** CSV.
- **Role:** industrial weak-word/defect evaluation.
- **Acquisition:** encoding-aware loader that attempts to normalize the local copy to UTF-8.

## Required reporting

The notebook writes `dataset_manifest.csv`. Use that file to report the exact dataset snapshot used in a particular run. Do not hard-code sample counts based on a previous run.

## Licensing and redistribution

This document records the sources configured in the notebook; it does not establish dataset ownership or grant redistribution permission. Verify the current license and terms on each source page. Unless redistribution is explicitly allowed, publish source links and download instructions rather than the raw datasets.
