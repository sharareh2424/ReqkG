# Human evaluation protocol

## Implementation retained

The interactive rating implementation is retained from the user-supplied `ReqKG_with_evaluation` notebook. The implementation supports separate rating files for independently entered rater identifiers (the project used `AR` and `MK`).

The blind rating interface contains three fields:

1. `correct_repair`: binary judgement of whether the ambiguity was correctly resolved.
2. `unsafe_modification`: binary judgement of whether unsupported information was added or the requirement was unsafely modified.
3. `intent_preservation_1to5`: five-point intent-preservation rating.

Each rater's file is saved separately and can be resumed after a runtime interruption. The hidden method key is joined only after ratings are collected.

## Analysis

The supplied notebook contains the agreement-analysis implementation. Report the actual overlap of rated items, missingness, agreement statistic, weighting choice, and confidence interval (if computed) from the run output. Do not claim a third adjudicator or a recalibrated rating protocol unless those procedures were actually performed.

## Public release and privacy

Do not publish raw rater files, hidden method keys, or any information that could identify assessors. Publish anonymized aggregate results only when consistent with consent and institutional requirements. Keep the blind key outside the public repository.
