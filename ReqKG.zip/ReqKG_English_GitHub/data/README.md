# Data directory

Place locally downloaded datasets here only if their licenses permit local use. The notebook also supports downloading configured sources automatically. Do not commit raw datasets unless redistribution is explicitly authorized.

Expected logical datasets:
- Fault-Prone SRS (`dataset.csv`)
- ORCHID (`Orchid-HEval/data.jsonl`)
- QuRE (`QuRE.csv`)
