# ReqKG-Guard

Research code accompanying the empirical study of evidence-grounded requirement refinement.

## Contents

- `notebooks/ReqKG.ipynb`: consolidated executable research notebook, including the supplied interactive human-evaluation implementation.
- `docs/DATASETS.md`: dataset sources, roles, formats, and access/licensing notes.
- `docs/HUMAN_EVALUATION.md`: human-rating workflow and data-protection guidance.
- `docs/REPRODUCIBILITY.md`: execution order, seeds, outputs, and interpretation rules.
- `data/README.md`: where to place permitted local datasets.
- `results/README.md`: generated result files and publication guidance.

## Datasets configured by the notebook

1. **Fault-Prone SRS** — Kaggle: `corpus4panwo/fault-prone-srs-dataset`.
2. **ORCHID** — Hugging Face: `SII-YDD/Orchid`, file `Orchid-HEval/data.jsonl`.
3. **QuRE** — Zenodo records `16049822` and `15656472`, file `QuRE.csv`.

The notebook creates `dataset_manifest.csv` at runtime. It records the actual row and column counts, hashes, and local file paths for the downloaded files. These values can vary by source revision; use the manifest from the run being reported.

## Quick start

1. Open `notebooks/ReqKG.ipynb` in Google Colab or Jupyter.
2. Install dependencies from `requirements-notebook.txt`.
3. Run cells in order.
4. Use a GPU runtime for transformer and generative-model experiments.
5. Inspect the generated manifest and status tables before reporting results.

## Important scientific-use notice

This repository preserves the experiment code and evaluation interface supplied for this project. It does not guarantee that all experimental branches complete successfully on every runtime. Partial, failed, or missing results must be reported as such. Do not replace missing values with zero or infer successful execution from the presence of a notebook cell.

## Data and privacy

Dataset source links do not grant redistribution rights. Check each dataset's license and terms before sharing any data. Do not commit raw human ratings, hidden method keys, participant-identifying information, API tokens, or private model caches.

## Citation

Please cite the associated manuscript. A DOI should be added only after a public archival release has actually been created.
