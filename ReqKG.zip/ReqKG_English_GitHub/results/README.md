# Results directory

Generated tables and manifests should be stored here for a specific run. Include the dataset manifest, split manifests, model status tables, per-item predictions where permitted, and aggregate metrics. Do not commit private caches, raw assessor files, hidden method keys, or credentials.
