# Dataset sources

The notebook retrieves the following datasets from their upstream sources. Dataset files are not bundled here.

| Dataset | Upstream source used by the notebook | Use in the study |
|---|---|---|
| Fault-Prone SRS | [Kaggle: corpus4panwo/fault-prone-srs-dataset](https://www.kaggle.com/datasets/corpus4panwo/fault-prone-srs-dataset) | Six-class requirements screening |
| ORCHID / Orchid-HEval | [Hugging Face dataset: SII-YDD/Orchid](https://huggingface.co/datasets/SII-YDD/Orchid) | Ambiguous-requirement repair benchmark |
| QuRE | [Zenodo record 16049822](https://zenodo.org/records/16049822) (the notebook also contains a fallback source) | Requirements-quality transfer assessment |

Before downloading or using a dataset, check the provider's current license, terms of use, citation instructions, and any access requirements. The fact that a dataset can be downloaded does not by itself grant permission to redistribute it.

The notebook records a dataset manifest with row counts, file paths, and SHA-256 hashes during execution. Retain that manifest with the corresponding run outputs.
