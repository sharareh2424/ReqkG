# ReqKG Guard

Research code and manuscript artifacts for **Evidence Authority in Automated Requirements Repair**.

ReqKG Guard studies evidence-governed requirements repair. It records assertion-level provenance and distinguishes whether a proposed repair is justified, unjustified, or unassessable. The workflow separates sentence-level screening, evidence-conditioned generation, and selective release.

## Repository contents

```text
ReqKG_GitHub_Package/
├── README.md
├── requirements.txt
├── .gitignore
├── notebooks/
│   └── ReqKG_with_Ui.ipynb
├── manuscript/
│   └── reqkg_final.pdf
└── data/
    └── README.md
```

- `notebooks/ReqKG_with_Ui.ipynb` — research notebook. The notebook's code cells have been preserved; this packaging step does not modify the code.
- `manuscript/reqkg_final.pdf` — manuscript supplied with this repository package.
- `requirements.txt` — Python packages imported or installed by the notebook. The notebook's first setup cell remains the primary environment setup instruction.
- `data/README.md` — dataset sources and access notes.

## Running the notebook

The notebook is designed for Google Colab and uses Google Drive for persistent data, caches, and outputs.

1. Upload `notebooks/ReqKG_with_Ui.ipynb` to Google Colab.
2. Select **Runtime → Change runtime type** and enable a GPU where available.
3. Run the notebook from top to bottom. Its setup cell installs the required packages and downloads the small English spaCy model.
4. Approve the Google Drive access request when prompted. The notebook stores downloaded datasets, intermediate caches, and generated outputs in the configured `ReqKG` Drive directory.
5. Review the run logs and generated tables/figures before interpreting results.

The first full run can take several hours and requires network access. GPU availability affects which generator configuration can be selected. Exact runtime and model availability depend on the Colab environment at execution time.

## Data

The notebook downloads the source datasets from their upstream providers. The datasets are **not redistributed in this repository**. See [`data/README.md`](data/README.md) and comply with each provider's current terms, citation requirements, and access restrictions.

## Important scope and interpretation

The manuscript reports separate screening, repair, release-coverage, and human-pilot outcomes. Operational release is not equivalent to a human-validated justified repair. In particular, the reported strict-policy abstention and relaxed-policy coverage results must not be interpreted as evidence that the additional released candidates are semantically justified. Independent judgments are required to estimate unjustified-release risk.

The manuscript also notes that the ORCHID repair experiment uses simulated project authority and that the human pilot is a separate sample. Consult the manuscript for cohort definitions, denominators, limitations, and statistical procedures.

## Reproducibility notes

- Record the execution date, Colab runtime, GPU, Python version, package versions, and model revisions when reproducing results.
- Preserve the generated dataset manifest, run logs, model outputs, and cache files for auditability.
- Do not commit API tokens, Kaggle credentials, private Drive contents, raw restricted datasets, or personally identifying annotation data.
- Large generated outputs and model checkpoints should be stored separately (for example, in an approved archival repository) and linked by version or checksum.

## Citation

Please cite the accompanying manuscript, **Evidence Authority in Automated Requirements Repair** (ReqKG Guard). Add the final journal citation or DOI here once it is assigned.

## License

No software license is included because the copyright holder and intended reuse terms have not been specified. Before making the repository public, choose and add a license that you are authorized to grant. Without a license, GitHub users do not receive permission to reuse, modify, or redistribute the code beyond the rights granted by applicable law.
